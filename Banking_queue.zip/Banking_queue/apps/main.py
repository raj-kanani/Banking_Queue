from fastapi import FastAPI, HTTPException, Depends, APIRouter
from typing import List, Union, Dict, Optional
import asyncio,models, pdb
from database import engine, SessionLocal, Base
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import Session, sessionmaker, relationship
from pydantic import BaseModel, Field
from uuid import UUID
from fastapi.encoders import jsonable_encoder
app = FastAPI()

models.Base.metadata.create_all(bind=engine)

def get_db():
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()


class Ticket(BaseModel):
    number: str
    status: Optional[str] = None


class Customer(BaseModel):
    name: str
    service_type: str


# Create a function to initialize the current_ticket_numbers dictionary
current_turn_number = 1

# Create counter for different departments
counter: Dict[str, List[Dict[str, Union[Customer, Ticket]]]] = {
    "Loan_Department": [],
    "Public_Accounts_Department": [],
    "Deposit_Accounts_Department": [],
}

# Counters for ticket numbers for each department
current_ticket_numbers: Dict[str, int] = {
    "Loan_Department": 1,
    "Public_Accounts_Department": 1,
    "Deposit_Accounts_Department": 1,
}


def create_ticket(db: Session, ticket: Ticket, department=None):
    if department not in counter:
        raise HTTPException(status_code=400, detail="Invalid department.")

    # Generate the ticket number with a department prefix and current number
    department_prefix = department.lower().replace(" ", "_")
    #get last number from database
    last_ticket =  (db.query(models.Ticket).filter
                    (models.Ticket.number == models.Ticket.number).order_by(models.Ticket.id.desc()).first())
    # Calculate the next ticket number
    if last_ticket:
        last_number = int(last_ticket.number.split('_')[-1])
        current_number = last_number + 1
    else:
        # If there are no existing tickets for the department, start with 1
        current_number = 1

    # Create a unique ticket number
    number = f"{department_prefix}_{current_number}"

    from models import Ticket, Customer
    _ticket = Ticket(number=number, status="Waiting")
    _customer = Customer(**ticket)
    current_ticket_numbers[department] += 1
    db.add(_ticket)
    db.add(_customer)
    db.commit()
    db.refresh(_ticket)
    db.refresh(_customer)
    return _ticket



@app.post("/take_ticket/{department}/", response_model=Ticket)
async def take_ticket(department: str, customer: Customer, db: Session = Depends(get_db)):
    if department not in counter:
        return {"number": -1, "status": "Invalid department"}
    ticket = create_ticket(db, customer.__dict__, department)
    return jsonable_encoder(ticket)


@app.get("/get_queue_list/{department}/")
async def get_queue_list(department: str,db: Session = Depends(get_db)):
    if department not in counter:
        raise HTTPException(status_code=400, detail="Invalid sector.")
    queue_list = db.query(models.Ticket).all()
    return queue_list


@app.get("/display_queue/{department}/", response_model=List[Customer])
async def display_queue(department: str, page: int = 1, page_size: int = 10):
    if department not in counter:
        raise HTTPException(status_code=400, detail="Invalid department.")

    queue = counter[department]
    start_index = (page - 1) * page_size
    end_index = start_index + page_size
    paginated_items = queue[start_index: end_index]
    return [item["customer"] for item in paginated_items]


@app.get("/current_token/{sector}/", response_model=Ticket)
async def current_token(sector: str):
    if sector not in counter:
        raise HTTPException(status_code=400, detail="Invalid sector.")

    current_number = current_ticket_numbers[sector]
    return Ticket(number=current_number)


@app.post("/next_customer/{department}/", response_model=Customer)
async def next_customer(department: str):
    if department not in counter:
        raise HTTPException(status_code=400, detail="Invalid department.")

    queue = counter[department]

    if not queue:
        raise HTTPException(status_code=400, detail="No customers in the queue.")

    next_customer_data = queue.pop(0)
    next_customer = next_customer_data["customer"]
    next_customer.status = "In progress"

    # Simulate the service time (you can replace this with actual service logic)
    await simulate_service_time(next_customer_data)

    next_customer.status = "Done"  # Update the status to 'Done'
    return next_customer


async def simulate_service_time(customer_data):
    await asyncio.sleep(5)  # Simulate a 5-second service time


@app.get("/customer_stores/{department}/", response_model=Dict[str, List[Customer]])
async def customer_stores_by_department(department: str):
    if department not in counter:
        raise HTTPException(status_code=400, detail="Invalid department.")

    # Get the queue for the specified department
    queue = counter[department]

    # Categorize customers by their statuses
    waiting_customers = [item["customer"] for item in queue if item["customer"].status == "Waiting"]
    in_progress_customers = [item["customer"] for item in queue if item["customer"].status == "In progress"]
    done_customers = [item["customer"] for item in queue if item["customer"].status == "Done"]

    # Create a dictionary to categorize customers
    categorized_customers = {
        "Waiting": waiting_customers,
        "In Progress": in_progress_customers,
        "Done": done_customers,
    }

    return categorized_customers

# apps.include_router(router, prefix="/bank-queuing")

from sqlalchemy import Column, Integer, String,DateTime, func
from sqlalchemy.orm import relationship
from database import Base


class Customer(Base):
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    service_type = Column(String)
    status = Column(String, default="Waiting")


class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(Integer, primary_key=True, index=True)
    number = Column(String, unique=True, index=True)
    status = Column(String, default="Waiting")
    # created_timestamp = Column(DateTime, server_default=func.now())